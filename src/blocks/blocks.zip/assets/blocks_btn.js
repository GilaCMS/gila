
gtableCommand.blocks = {
  fa: "bars",
  title: "Blocks",
  fn: function(table,id){
      window.location.href = 'blocks/?t='+table.name+'&id='+id
  }
};
