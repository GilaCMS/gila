<?php

return [
  "heading"=>[],
  "subheading"=>[],
  "cards"=>[
    "type"=>"list",
    "fields"=>[
      "image"=>["type"=>"media"],
      "title"=>[],
      "text"=>[],
      "link_text"=>[],
      "link_url"=>[]
    ],
    "default"=>'[["src/core/assets/cogs.png","Card","Text","",""],["src/core/assets/cogs.png","Card","Text","",""],["src/core/assets/cogs.png","Card","Text","",""]]'
  ]
];
