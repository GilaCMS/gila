<?php

return [
  "heading"=>[],
  "text"=>[],
  "image"=>[
    "type"=>"media"
  ],
  "primary_link"=>[],
  "primary_text"=>[],
  "secondary_link"=>[],
  "secondary_text"=>[]
];
