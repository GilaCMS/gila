<?php

return [
  'items'=>[
    'type'=>'list',
    'fields'=>[
      'question'=>[],
      'answer'=>[]
    ]
  ]
];
