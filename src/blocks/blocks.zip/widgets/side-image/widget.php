<?php

return [
  "text"=>[
    "type"=>"paragraph",
    "allow-tags"=>true
  ],
  "image"=>[
    "type"=>"media"
  ],
  "side"=>[
    "type"=>"radio",
    "options"=>["Left", "Right"]
  ]
];
