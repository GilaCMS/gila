*1.1.1*
Display bigger images