<?php

return [
    'text'=>[
        'default'=>'Widget Example'
    ],
    'color'=>[
        'title'=>'Border Color',
        'type'=>'color',
        'default'=>'#ff0000'
    ]
];
