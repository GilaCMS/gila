<div style="border:3px solid <?=$widget_data->color?>">
  <?=$widget_data->text?>
</div>
