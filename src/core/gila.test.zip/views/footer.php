
</div>
<footer>
    <p>
        <br>Powered by <a href="http://gilacms.com" target="_blank">Gila</a>
    </p>
</footer>
<?php View::scriptAsync("core/lazyImgLoad.js")?>

</body>

</html>
