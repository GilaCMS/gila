<!DOCTYPE html>
<html lang="<?=Config::config('language')?>">
<?=View::head()?>
