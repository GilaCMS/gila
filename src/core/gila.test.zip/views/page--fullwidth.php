<?php View::includeFile('header.php')?>
<?=$text?>
<?php View::includeFile('footer.php')?>
