
<?php View::alerts()?>
<style>#main-wrapper>div{background: inherit !important;border:none}</style>
<div class="widget-area-dashboard wrapper">
  <?php View::widgetArea('dashboard'); ?>
</div>
