
<h3>'<?=$search?>' <?=__('Search results')?></h3>
<?php include view::getViewFile('blog-list.php'); ?>
