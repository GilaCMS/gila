<?php

return [
    'text'=>[
        'type'=>'tinymce',
        'default'=>'Paragraph'
    ]
];
