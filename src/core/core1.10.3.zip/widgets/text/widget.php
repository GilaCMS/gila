<?php

return [
    'text'=>[
        'type'=>'textarea',
        'default'=>'This is a text/html widget',
        'helptext'=>'Do not paste here code for untrusty websites. It could compromise the security of your site.'
    ]
];
