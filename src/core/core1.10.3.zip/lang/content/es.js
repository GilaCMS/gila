var lang_array={
	"Group by":"Agrupados de",
	"Save":"Guardar",
	"New":"Nuevo",
	"Import":"Imoprtar",
	"Export":"Exportar",
	"Report":"Reporte",
	"Update":"Actualizar",
	"Cancel":"Cancelar",
	"New Registry":"Nuevo Registro",
	"Edit Registry":"Editar Registro",
	"Open":"Abrir",
	"Search":"Buscar",
	
	"Yes":"Si",
	"No":"No",
	
	"Delete registry?":"Eliminar registro?"
};

