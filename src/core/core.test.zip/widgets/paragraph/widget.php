<?php

return [
    'text'=>[
        'type'=>'paragraph',
        'default'=>'Paragraph',
        'allow-tags'=>true
    ]
];
