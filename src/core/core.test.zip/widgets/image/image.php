<figure style="margin:0">
  <img src="<?=_url($widget_data->image)?>" alt="<?=($widget_data->description??'')?>"/>
  <figcaption><?=$widget_data->caption?></figcaption>
</figure>
