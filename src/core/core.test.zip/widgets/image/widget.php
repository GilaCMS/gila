<?php

return [
    'image'=>[
        "type"=>"media",
        "default"=>"assets/core/photo.png"
    ],
    'caption'=>[
        "type"=>"text"
    ]
];
