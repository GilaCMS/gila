<?php

return [
    'image'=> [
        "type"=>"media",
        "default"=>"assets/core/photo.png"
    ],
    'description'=> [],
    'caption'=> [
        "type"=>"paragraph"
    ]
];
