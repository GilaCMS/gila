<?php

return [
    "success_msg"=> [
        "default"=> "The email was send succesfully."
    ]
];
