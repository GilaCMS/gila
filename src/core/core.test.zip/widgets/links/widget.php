<?php

return [
    'links'=>[
        'type'=>'list',
        'fields'=>[
            'text'=>[],
            'url'=>[],
        ],
        'default'=>'[["",""]]'
    ]
];
