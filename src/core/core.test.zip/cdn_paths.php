<?php

return [
  'lib/jquery/jquery-3.3.1.min.js'=> 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js',
  'lib/select2/select2.min.js'=> 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.1/js/select2.min.js',
  'lib/select2/select2.min.css'=> 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.1/css/select2.min.css',
  'lib/bootstrap/bootstrap.min.js'=> 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js',
  'lib/bootstrap/bootstrap.min.css'=> 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css',
  'lib/font-awesome/font-awesome.min.css'=> 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css',
  'lib/tinymce/tinymce.min.js'=> 'https://cdnjs.cloudflare.com/ajax/libs/tinymce/4.7.9/tinymce.min.js',
  'lib/slick/slick.min.js'=> 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js'  
];
