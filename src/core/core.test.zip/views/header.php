<!DOCTYPE html>
<html lang="<?=Config::config('language')?>">
<?php View::head()?>
<a href="<?=Config::base_url()?>"><h1><?=Config::config('title')?></h1></a>
<h3><?=Config::config('slogan')?><h3>
<div>
