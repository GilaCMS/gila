<!DOCTYPE html>
<html lang="<?=Gila::config('language')?>">
<?php View::head()?>
<a href="<?=Gila::base_url()?>"><h1><?=Gila::config('title')?></h1></a>
<h3><?=Gila::config('slogan')?><h3>
<div>
