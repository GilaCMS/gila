<?php Controller::admin()?>
<?php View::includeFile('admin/header.php')?>
<?=$text?>
<?php View::includeFile('admin/footer.php')?>
