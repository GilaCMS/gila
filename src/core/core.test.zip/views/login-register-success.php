<!DOCTYPE html>
<html lang="<?=Gila::config('language')?>">

<head>
  <base href="<?=Gila::base_url()?>">
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title><?=Gila::config('title')?> - <?=__('Register')?></title>

  <?=View::css('core/gila.min.css')?>
  <?=View::css('lib/font-awesome/css/font-awesome.min.css')?>
</head>

<body>

  <div class="gl-4 centered">
    <div class="g-form wrapper g-card">
      <div class="border-buttom-main_ text-align-center">
        <div style="width:16%;display:inline-block">
          <i class="fa fa-5x fa-check" style="color:green"></i>
        </div>
        <h3><?=__('register_success')?></h3>
      </div>
      <a class="btn btn-success btn-block" href="<?=Gila::url('login')?>"><?=__('Log In')?></a>
    </div>
  </div>

</body>

</html>
