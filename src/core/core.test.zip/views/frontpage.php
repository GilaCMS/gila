<?php View::widgetArea('slide'); ?>
<?php include __DIR__.'/blog-list.php'; ?>
