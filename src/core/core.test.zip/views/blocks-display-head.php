<!DOCTYPE html>
<html lang="<?=Gila::config('language')?>">
<?=View::head()?>
