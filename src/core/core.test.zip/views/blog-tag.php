
<h3>Tag <?=htmlspecialchars($tag)?></h3>
<?php View::includeFile('blog-list.php'); ?>
