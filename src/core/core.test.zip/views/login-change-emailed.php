<?php View::includeFile('login-header.php');?>

  <div class="gl-4 centered wrapper g-card bg-white">
    <div class="border-buttom-main_ text-align-center">
      <div style="width:16%;display:inline-block">
        <i class="fa fa-5x fa-envelope" style="color:green"></i>
      </div>
      <h3><?=__('reset_html1')?></h3>
      <p><?=__('reset_html2')?></p>
    </div>
  </div>

</body>

</html>
