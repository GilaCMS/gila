
<h3>Tag <?=$c->tag?></h3>
<?php view::includeFile('blog-list.php'); ?>
