
</div>
<footer>
    <p>
        <br>Powered by <a href="http://gilacms.com" target="_blank">Gila</a>
    </p>
</footer>
<script src="src/core/assets/lazyImgLoad.js" async></script>

</body>

</html>
