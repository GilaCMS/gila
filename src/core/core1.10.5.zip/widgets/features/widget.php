<?php

return [
    'features'=>[
        'type'=>'list',
        'fields'=>[
            'image'=>['type'=>'media','default'=>'assets/vector/cogs.png'],
            'name'=>[],
            'text'=>[],
            'url'=>[],
        ],
        'default'=>'[]'
    ]
];
