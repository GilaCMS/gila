<?php

return [
    'n'=>[
      'title'=>'Number of tags',
      'default'=>'100'
    ]
];
