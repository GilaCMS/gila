var lang_array={
  "Group by":"Grouper par",
  "Save":"Sauvegarder",
  "New":"Nouveau",
  "Import":"Importer",
  "Export":"Exporter",
  "Report":"Signaler",
  "Update":"Actualiser",
  "Cancel":"Annuler",
  "New Registry":"Nouveau Registre",
  "Edit Registry":"Editer Registre",
  "Open":"Ouvrir",
  "Search":"Chercher",

  "Yes":"Oui",
  "No":"Non",

  "Delete registry?":"Êtes-vous sûr de vouleir supprimer définitivement le registre ?"
};
