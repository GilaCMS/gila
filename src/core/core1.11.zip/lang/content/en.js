var lang_array={
	"Delete registry?":"Are you sure you want to delete permament the registry?"
};
