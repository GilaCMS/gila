<?php view::widget_area('slide'); ?>
<?php include __DIR__.'/blog-list.php'; ?>
