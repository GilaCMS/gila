<figure>
	<img src="<?=_url($widget_data->image)?>"/>
	<figcaption><?=$widget_data->caption?></figcaption>
</figure>
