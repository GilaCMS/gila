
<h3>Author: <?=$c->author?></h3>
<?php view::includeFile('blog-list.php'); ?>
