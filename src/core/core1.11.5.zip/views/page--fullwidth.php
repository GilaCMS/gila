<?php view::includeFile('header.php')?>
<?=$text?>
<?php view::includeFile('footer.php')?>
