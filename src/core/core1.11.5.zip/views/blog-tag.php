
<h3>Tag <?=htmlspecialchars($c->tag)?></h3>
<?php view::includeFile('blog-list.php'); ?>
