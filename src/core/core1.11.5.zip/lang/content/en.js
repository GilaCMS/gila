var lang_array={
	"Delete registry?":"Are you sure you want to delete permament the registry?",
  _gallery:'Media Gallery',
  _new_filepath: 'Please enter new file path',
  _file_saved: "File saved successfully",
  _select_file: 'Please select a media file',
  _new_folder: "Create new folder",
  _file_deleted: "File deleted successfully"
};
