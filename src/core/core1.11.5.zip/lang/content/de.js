var lang_array={
	"Group by":"Gruppieren nach",
	"Save":"Speichern",
	"New":"Neu",
	"Import":"Importieren",
	"Export":"Exportieren",
	"Report":"Bericht",
	"Update":"Aktualisieren",
	"Cancel":"Stornieren",
	"New Registry":"Nue Registrierung",
	"Edit Registry":"Registrierung bearbeiten",
	"Open":"Öffnen",
	"Search":"Suche",
	
	"Yes":"Ja",
	"No":"Nein",
	
	"Delete registry?":"Registrierung löschen?"
};
