var lang_array={
	"Group by":"Gruppieren nach",
	"Save":"Speichern",
	"New":"Uus",
	"Import":"Impordi",
	"Export":"Ekspordi",
	"Report":"Aruanne",
	"Update":"Uuenda",
	"Cancel":"Tühista",
	"New Registry":"Uus registreerimine",
	"Edit Registry":"Redigeeri registreerimine",
	"Open":"Avatud",
	"Search":"Otsing",
	
	"Yes":"Jah",
	"No":"Ei",
	
	"Delete registry?":"Kas kustutada register?"
};

