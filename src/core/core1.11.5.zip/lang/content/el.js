var lang_array={
	"Group by":"Ομαδοποίηση",
	"Save":"Αποθήκευση",
	"New":"Νέο",
	"Import":"Εισαγωγή",
	"Export":"Εξαγωγή",
	"Report":"Reporte",
	"Update":"Ανανέωση",
	"Cancel":"Ακύρωση",
	"New Registry":"Νέα Εγγραφή",
	"Edit Registry":"Επεξεργασία Εγγραφής",
	"Open":"Άνοιγμα",
	"Search":"Αναζήτηση",
	
	"Yes":"Ναι",
	"No":"Όχι",
	
	"Delete registry?":"Διαγραφή εγγραφής;"
};
