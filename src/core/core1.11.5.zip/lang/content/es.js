var lang_array={
  "Group by":"Agrupados de",
  "Save":"Guardar",
  "New":"Nuevo",
  "Import":"Imoprtar",
  "Export":"Exportar",
  "Report":"Reporte",
  "Update":"Actualizar",
  "Cancel":"Cancelar",
  "New Registry":"Nuevo Registro",
  "Edit Registry":"Editar Registro",
  "Open":"Abrir",
  "Search":"Buscar",

  "Yes":"Si",
  "No":"No",

  "Delete registry?":"Eliminar registro?",

  _gallery:'Galleria',
  _new_filepath: 'Porfavor inscribe una nueva ruta',
  _file_saved: "Archivo se guardo",
  _select_file: 'Porfavor elige un archivo',
  _new_folder: "Crear nueva carpeta",
  _file_deleted: "Archivo se elimino exitosamente"
};
