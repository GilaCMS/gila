<?php

return [
	'facebook'=>[],
	'twitter'=>[],
	'linkedin'=>[],
	'pinterest'=>[],
	'youtube'=>[],
	'instagram'=>[],
	'google'=>[],
	'medium'=>[],
	'github'=>[],
	'tumblr'=>[],
	'vk'=>[],
	'twitch'=>[],
	'slack'=>[],
	'codepen'=>[],
	'stack-overflow'=>[],
	'soundcloud'=>[],
	'rss'=>[]
];
