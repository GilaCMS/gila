<?php

return [
    'image'=>[
        "type"=>"media",
        "default"=>"src/core/assets/photo.png"
    ],
    'caption'=>[
        "type"=>"text"
    ]
];
