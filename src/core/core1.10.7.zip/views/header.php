<!DOCTYPE html>
<html lang="<?=gila::config('language')?>">
<?php view::head()?>
<a href="<?=gila::base_url()?>"><h1><?=gila::config('title')?></h1></a>
<h3><?=gila::config('slogan')?><h3>
<div>
