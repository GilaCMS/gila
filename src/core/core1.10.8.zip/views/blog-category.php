
<h3>Category <?=$c->category?></h3>
<?php view::includeFile('blog-list.php'); ?>
