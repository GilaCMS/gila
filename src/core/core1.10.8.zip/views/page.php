<!-- Post Header -->
<!-- Set your background image for this header on the line below. -->
<div class="wrapper">
  <h1><?=$title?></h1>

  <div>
      <?=$text?>
  </div>
</div>
