<?php

return [
    'text'=>[
        'type'=>'tinymce',
        'default'=>'Paragraph',
        'allow-tags'=>true
    ]
];
