<?php

return [
    'n_post'=>[
        'title'=>'Number of posts',
        'default'=>'5',
    ],
    'category'=>[
        'title'=>'Category',
        "type"=>"postcategory"
    ]
];
