<figure>
	<img src="<?=$widget_data->image?>"/>
	<figcaption><?=$widget_data->caption?></figcaption>
</figure>
