<?php

return [
    'text'=>[
        'type'=>'paragraph',
        'allow-tags'=>'<a><br><ul><ol><li><h1><h2><h3><h4><del><sub><p><pre><code><img><b><i><blockquote><del><ins><sub><sup><figure>'
    ]
];
