<?php

return [
  'en'=> 'English',
  'es'=> 'Spanish (Español)',
  'fr'=> 'French (Français)',
  'pt'=> 'Portuguese (Português)',
  'zh'=> 'Chinese (中文)',
  'ru'=> 'Russian (русский)',
  'ja'=> 'Japanese (日本語)',
  'fa'=> 'Persian (فارسی)',
  'it'=> 'Italian (Italiano)',
  'ms'=> 'Malay',
  'id'=> 'Indonesian',
  'ar'=> 'Arabic (عربى)',
  'tr'=> 'Turkish (Türk)',
  'de'=> 'German (Deutsche)',
  'el'=> 'Greek (Ελληνικά)',
  'et'=> 'Estonian (Eesti)'
];

