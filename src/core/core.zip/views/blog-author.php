
<h3>Author: <?=$author?></h3>
<?php View::includeFile('blog-list.php'); ?>
