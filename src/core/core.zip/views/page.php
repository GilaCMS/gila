<?php View::includeFile('header.php')?>
<div class="wrapper">
  <h1><?=$title?></h1>

  <div>
      <?=$text?>
  </div>
</div>
<?php View::includeFile('footer.php')?>
