
<h3>'<?=htmlentities($_GET['search'])?>' <?=__('Search results')?></h3>
<?php include 'blog-list.php'; ?>
