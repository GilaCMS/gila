<div class="pad"><p><?=$widget_data->text;?></p></div>
