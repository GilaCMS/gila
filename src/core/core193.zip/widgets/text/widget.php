<?php

return [
    'text'=>[
        'type'=>'textarea',
        'default'=>'This is a text/html widget'
    ]
];
