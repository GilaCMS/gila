<div class="pad">
	<h3><?=$widget_data->label?></h3>
	<h4><?=$widget_data->sublabel?></h4>
	<p><?=$widget_data->summary?></p>
	<a href><?=$widget_data->link?></a>
</div>
