<?php

return [
    'label'=>[
    ],
    'sublabel'=>[
    ],
    'image'=>[
        "type"=>"media"
    ],
    'summary'=>[
        "type"=>"textarea"
    ],
    'link'=>[
    ]
];
