<?php

array_push(gila::$widget_area,'head','body','foot','sidebar','post.after','dashboard','frontpage');
