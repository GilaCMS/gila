
<h3>Tag: <i><?=$c->tag?></i></h3>
<?php include 'blog-list.php'; ?>
