
    </div>
    <footer class="wrapper" style="">
        <div class="footer-widget">
            <?php view::widget_area('foot')?>
        </div>
        <p class="copyright footer-text">
            <?=gila::option('theme.footer-text','Copyright &copy; Your Website 2017');?>
            <span style="float:right">Powered by <a href="http://gilacms.com" target="_blank">Gila CMS</a></span>
        </p>
    </footer>

  </div>
</body>

</html>
