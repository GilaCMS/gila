
  <h1><?=$c->title?></h1>

  <div>
      <?=$c->text?>
  </div>
